# Bauhaus Font
Bauhaus Systemless Font.

## Instructions ##
* __Install Module__ via Magisk Manager/Recovery
* __Reboot__ Device

## Screenshot ##

<img src="https://cdn1.savepice.ru/uploads/2018/10/26/98cb68ce024956850f8f606112506792-full.png" height="78" width="390" alt="Screenshot">
